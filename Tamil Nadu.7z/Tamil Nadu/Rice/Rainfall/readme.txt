The rainfall feasible months are:

August
September
October
