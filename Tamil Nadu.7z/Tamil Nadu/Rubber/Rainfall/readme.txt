The rainfall feasible months are:

October
December