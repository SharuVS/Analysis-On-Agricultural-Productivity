The rainfall feasible months are:

April
May
June
July
