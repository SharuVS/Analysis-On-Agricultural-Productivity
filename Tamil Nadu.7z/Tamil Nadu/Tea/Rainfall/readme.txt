The rainfall feasible months are:

September
December