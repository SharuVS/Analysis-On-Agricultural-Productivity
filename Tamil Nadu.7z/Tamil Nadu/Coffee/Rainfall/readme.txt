The rainfall feasible month is:

December