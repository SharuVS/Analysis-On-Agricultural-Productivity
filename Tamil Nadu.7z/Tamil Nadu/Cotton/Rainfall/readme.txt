The rainfall feasible months are:

May
August
