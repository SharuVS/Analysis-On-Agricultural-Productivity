The rainfall feasible month is:


February
