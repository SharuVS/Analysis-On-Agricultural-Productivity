The rainfall feasible months are:

April
October