The rainfall feasible months are:

April
May
August
September
