The rainfall feasible months are:

March
April
October
