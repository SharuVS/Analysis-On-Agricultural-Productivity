The rainfall feasible month is:

April
