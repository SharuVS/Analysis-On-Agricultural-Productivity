The temperature suitable for the growth of this crop is in the months:

March
April
May
September
October