The rainfall feasible months are:

March
April
May
September
October
