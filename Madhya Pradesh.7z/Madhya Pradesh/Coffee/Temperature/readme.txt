The temperature suitable for the growth of this crop is in the months:

January
February
March
August
September
October
November
December