The temperature suitable for the growth of this crop is in the months:

January
February
July
August
September
October
November
December