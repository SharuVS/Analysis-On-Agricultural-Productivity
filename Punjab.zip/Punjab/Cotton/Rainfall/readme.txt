The rainfall feasible month is:

June
