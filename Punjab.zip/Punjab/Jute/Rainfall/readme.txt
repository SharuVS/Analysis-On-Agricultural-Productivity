The rainfall feasible months are:

June
September