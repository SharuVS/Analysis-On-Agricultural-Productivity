The rainfall feasible months are:

July
August

