The temperature suitable for the growth of the crop is in the months:

February
March
April
October
November