The temperature suitable for the growth of thes crop is in the months:

January
February
March
November
December