Temperature suitable for the growth of the crop is in the months:
March 
April
May
June
July
August
September
October
November
