Rainfall is feasible in the months:
March 
April
May
October
