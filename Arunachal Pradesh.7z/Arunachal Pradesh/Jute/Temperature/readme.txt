Temperature is not suitable for the growth of the crop.
