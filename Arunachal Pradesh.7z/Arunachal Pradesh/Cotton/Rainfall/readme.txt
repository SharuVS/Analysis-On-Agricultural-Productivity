Rainfall is feasible in the months:
March 

