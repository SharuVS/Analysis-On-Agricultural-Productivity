Temperature suitable for the growth of the crop is in the months:
May
June
July
August
September
October
