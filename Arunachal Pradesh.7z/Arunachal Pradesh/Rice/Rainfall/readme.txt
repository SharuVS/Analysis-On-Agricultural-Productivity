Rainfall is feasible in the months:
Febrary
March 
April
May
October
