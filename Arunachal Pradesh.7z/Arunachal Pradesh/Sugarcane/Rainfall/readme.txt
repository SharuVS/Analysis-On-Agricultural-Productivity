Rainfall is feasible in the months:
Febrary
March 
October
