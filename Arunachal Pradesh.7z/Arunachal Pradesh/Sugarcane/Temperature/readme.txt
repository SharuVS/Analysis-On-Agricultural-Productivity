Temperature suitable for the growth of the crop is in the months:
June
July
August
September

