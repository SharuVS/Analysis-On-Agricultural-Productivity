Temperature suitable for the growth of the crop is in the months:
January
Febrary
March 
October
November
December