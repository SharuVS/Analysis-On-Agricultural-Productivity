Rainfall is feasible in the months:
July 
September

