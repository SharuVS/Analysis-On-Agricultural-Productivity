Rainfall is feasible in the months:
June
July 
August
September

