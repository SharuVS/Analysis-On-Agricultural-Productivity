Rainfall is feasible in the months:
May
September
