The rainfall feasible month is:

August
