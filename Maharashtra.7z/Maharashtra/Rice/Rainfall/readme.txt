Rainfall is feasible in the months:
June
August
September


