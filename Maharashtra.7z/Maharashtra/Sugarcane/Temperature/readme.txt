Temperature suitable for the growth of the crop is in the months:
Febrary
August
September
October
November
