Temperature suitable for the growth of the crop is in the months:
Febrary
March 
April
May
June
July
August
September
October
