Rainfall is feasible in the months:
October
