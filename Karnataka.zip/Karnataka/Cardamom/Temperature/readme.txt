The temperature for the crop is feasible throughout the year.
