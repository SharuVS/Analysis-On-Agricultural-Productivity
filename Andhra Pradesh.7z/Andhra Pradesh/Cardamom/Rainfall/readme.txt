The rainfall feasible months are:

September
October
November
