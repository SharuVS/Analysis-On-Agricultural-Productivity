The rainfall feasible month is:

October
