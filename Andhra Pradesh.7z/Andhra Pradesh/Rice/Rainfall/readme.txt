The rainfall feasible months are:

June
July
August
September
